/*
class TFT	//tag
{
	class S6	//category
	{
		class enableCamera {
			file  = "functions\enableCamera.sqf";
		};
	};
};
*/
